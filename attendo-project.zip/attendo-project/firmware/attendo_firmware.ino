/*
  Attendo -- ESP32 + AS608 + DS3231 RTC + ILI9341 TFT
  Attendance & Enrollment Firmware

  Note: this firmware only ever deals with a fingerprint slot number -- it
  has no concept of "section" or how a student got into the system (manual
  entry vs Excel import), so nothing here changes for that feature. The
  device just gets told "assign slot N", same as always.
*/

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Adafruit_Fingerprint.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <Wire.h>
#include <RTClib.h>
#include <LittleFS.h>

const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* BACKEND_BASE_URL = "http://192.168.1.50:4000/api";
const char* DEVICE_KEY = "ESP32-MAIN-01";
const char* TIMEZONE_OFFSET = "+08:00";

#define TFT_CS   15
#define TFT_DC    2
#define TFT_RST   4

#define COLOR_BG     ILI9341_BLACK
#define COLOR_TEXT   ILI9341_WHITE
#define COLOR_TEAL   0x1532
#define COLOR_AMBER  0xE501
#define COLOR_CORAL  0xE2AA
#define COLOR_STEEL  0x8C94
#define COLOR_DOTOFF 0x2965

const unsigned long SCHEDULE_REFRESH_MS = 15UL * 60UL * 1000UL;
const unsigned long COMMAND_POLL_MS     = 3000;
const unsigned long QUEUE_FLUSH_MS      = 20000;
const unsigned long SCAN_COOLDOWN_MS    = 1500;
const unsigned long DISPLAY_REFRESH_MS  = 1000;

#define QUEUE_FILE "/queue.jsonl"
#define MAX_SCHEDULES 60

struct ScheduleEntry {
  int dayOfWeek;
  int startMinutes;
  int endMinutes;
  String subjectName;
};

Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);
HardwareSerial fingerSerial(2);
Adafruit_Fingerprint finger(&fingerSerial);
RTC_DS3231 rtc;

ScheduleEntry cachedSchedule[MAX_SCHEDULES];
int scheduleCount = 0;
bool scheduleEverLoaded = false;

unsigned long lastScheduleFetch = 0;
unsigned long lastCommandPoll = 0;
unsigned long lastQueueFlush = 0;
unsigned long lastScanTime = 0;
unsigned long lastDisplayRefresh = 0;

String lastResultStatus = "";
String lastResultSubject = "";

uint8_t autoSize(const String &s) {
  if (s.length() <= 8) return 4;
  if (s.length() <= 14) return 3;
  return 2;
}

void centerText(const String &text, int y, uint8_t size) {
  int16_t x1, y1;
  uint16_t w, h;
  tft.setTextSize(size);
  tft.getTextBounds(text, 0, y, &x1, &y1, &w, &h);
  int x = (tft.width() - (int)w) / 2;
  if (x < 0) x = 0;
  tft.setCursor(x, y);
  tft.print(text);
}

void drawConnectionDot(bool wifiOnline) {
  tft.fillRect(0, 0, tft.width(), 26, COLOR_BG);
  tft.fillCircle(16, 13, 5, wifiOnline ? COLOR_TEAL : COLOR_CORAL);
  tft.setTextSize(1);
  tft.setTextColor(COLOR_STEEL);
  tft.setCursor(30, 9);
  tft.print(wifiOnline ? "ONLINE" : "OFFLINE");
}

void initDisplay() {
  tft.begin();
  tft.setRotation(1);
  tft.fillScreen(COLOR_BG);
  tft.setTextWrap(false);
}

void displayStatusScreen(String clockText, bool wifiOnline, bool classActive,
                          String subjectName, int queueCount) {
  tft.fillScreen(COLOR_BG);
  drawConnectionDot(wifiOnline);
  tft.setTextColor(COLOR_STEEL);
  centerText(clockText, 34, 2);
  int midY = tft.height() / 2 - (classActive ? 26 : 18);
  if (classActive) {
    tft.setTextColor(COLOR_TEXT);
    centerText(subjectName, midY, autoSize(subjectName));
    tft.setTextColor(COLOR_STEEL);
    centerText("in session", midY + 40, 2);
  } else {
    tft.setTextColor(COLOR_STEEL);
    centerText("No class", midY, 3);
    centerText("scanner idle", midY + 34, 2);
  }
  if (queueCount > 0) {
    tft.setTextColor(COLOR_AMBER);
    centerText(String(queueCount) + " queued offline", tft.height() - 30, 2);
  }
}

void displayScanResult(String slotLabel, String status, String subjectName) {
  uint16_t color = (status == "present") ? COLOR_TEAL
                  : (status == "late" || status == "queued") ? COLOR_AMBER
                  : COLOR_CORAL;
  String label = (status == "present") ? "PRESENT"
               : (status == "late") ? "LATE"
               : (status == "queued") ? "QUEUED"
               : "REJECTED";
  tft.fillScreen(COLOR_BG);
  tft.setTextColor(COLOR_STEEL);
  centerText(slotLabel, tft.height() / 2 - 60, 2);
  tft.setTextColor(color);
  centerText(label, tft.height() / 2 - 20, 4);
  tft.setTextColor(COLOR_STEEL);
  centerText(subjectName, tft.height() / 2 + 40, 2);
}

void displayMessage(String line1, String line2, uint16_t color) {
  tft.fillScreen(COLOR_BG);
  int midY = tft.height() / 2 - 24;
  tft.setTextColor(color);
  centerText(line1, midY, autoSize(line1));
  tft.setTextColor(COLOR_STEEL);
  centerText(line2, midY + 34, 2);
}

void displayEnrollStep(int step) {
  tft.fillScreen(COLOR_BG);
  tft.setTextColor(COLOR_TEXT);
  String text = (step == 1) ? "Place finger"
              : (step == 2) ? "Remove finger"
              : (step == 3) ? "Place again"
              : "Saving";
  centerText(text, tft.height() / 2 - 16, 3);
  int dotSpacing = 26;
  int startX = (tft.width() - dotSpacing * 3) / 2;
  int y = tft.height() / 2 + 40;
  for (int i = 0; i < 4; i++) {
    uint16_t c = (i < step) ? COLOR_TEAL : COLOR_DOTOFF;
    tft.fillCircle(startX + i * dotSpacing, y, 4, c);
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  initDisplay();
  displayMessage("Attendo", "Starting up...", COLOR_TEXT);

  fingerSerial.begin(57600, SERIAL_8N1, 16, 17);
  finger.begin(57600);
  if (finger.verifyPassword()) {
    Serial.println("AS608 sensor found and ready.");
  } else {
    Serial.println("AS608 sensor NOT found. Check wiring.");
    displayMessage("Hardware error", "Sensor not found", COLOR_CORAL);
    while (true) delay(1000);
  }

  Wire.begin();
  if (!rtc.begin()) {
    Serial.println("RTC NOT found. Check wiring.");
    displayMessage("Hardware error", "RTC not found", COLOR_CORAL);
    while (true) delay(1000);
  }
  if (rtc.lostPower()) {
    Serial.println("RTC lost power -- time is not set. Set it once, then reflash without that line.");
  }

  if (!LittleFS.begin(true)) {
    Serial.println("Failed to mount LittleFS.");
  }

  connectWiFi();
  if (WiFi.status() == WL_CONNECTED) fetchSchedule();
  refreshStatusScreen();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  bool online = WiFi.status() == WL_CONNECTED;

  if (online && millis() - lastScheduleFetch >= SCHEDULE_REFRESH_MS) {
    lastScheduleFetch = millis();
    fetchSchedule();
  }
  if (online && millis() - lastCommandPoll >= COMMAND_POLL_MS) {
    lastCommandPoll = millis();
    checkForEnrollCommand();
  }
  if (online && millis() - lastQueueFlush >= QUEUE_FLUSH_MS) {
    lastQueueFlush = millis();
    flushOfflineQueue();
  }
  if (isClassInSession()) attemptAttendanceScan();
  if (millis() - lastDisplayRefresh >= DISPLAY_REFRESH_MS) {
    lastDisplayRefresh = millis();
    refreshStatusScreen();
  }
  delay(50);
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("Connecting to WiFi");
  displayMessage("Connecting WiFi", String(WIFI_SSID), COLOR_STEEL);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) { delay(500); Serial.print("."); attempts++; }
  if (WiFi.status() == WL_CONNECTED) Serial.println("\nConnected. IP: " + WiFi.localIP().toString());
  else Serial.println("\nNo WiFi yet -- will keep operating offline using cached schedule.");
}

bool isClassInSession() {
  if (!scheduleEverLoaded) return false;
  DateTime now = rtc.now();
  int dow = now.dayOfTheWeek();
  int minutes = now.hour() * 60 + now.minute();
  for (int i = 0; i < scheduleCount; i++) {
    if (cachedSchedule[i].dayOfWeek == dow && minutes >= cachedSchedule[i].startMinutes && minutes <= cachedSchedule[i].endMinutes) return true;
  }
  return false;
}

String getActiveSubjectName() {
  DateTime now = rtc.now();
  int dow = now.dayOfTheWeek();
  int minutes = now.hour() * 60 + now.minute();
  for (int i = 0; i < scheduleCount; i++) {
    if (cachedSchedule[i].dayOfWeek == dow && minutes >= cachedSchedule[i].startMinutes && minutes <= cachedSchedule[i].endMinutes) return cachedSchedule[i].subjectName;
  }
  return "";
}

void fetchSchedule() {
  HTTPClient http;
  String url = String(BACKEND_BASE_URL) + "/device/schedule";
  http.begin(url);
  http.addHeader("X-Device-Key", DEVICE_KEY);
  int status = http.GET();
  if (status != 200) { Serial.printf("Schedule fetch failed (HTTP %d)\n", status); http.end(); return; }
  String response = http.getString();
  http.end();
  JsonDocument doc;
  if (deserializeJson(doc, response)) { Serial.println("Failed to parse schedule response."); return; }
  JsonArray arr = doc.as<JsonArray>();
  scheduleCount = 0;
  for (JsonObject item : arr) {
    if (scheduleCount >= MAX_SCHEDULES) break;
    cachedSchedule[scheduleCount].dayOfWeek = item["dayOfWeek"];
    cachedSchedule[scheduleCount].startMinutes = timeStrToMinutes(item["startTime"].as<String>());
    cachedSchedule[scheduleCount].endMinutes = timeStrToMinutes(item["endTime"].as<String>());
    cachedSchedule[scheduleCount].subjectName = item["subjectName"].as<String>();
    scheduleCount++;
  }
  scheduleEverLoaded = true;
  Serial.printf("Schedule synced: %d entries cached.\n", scheduleCount);
}

int timeStrToMinutes(String hhmm) {
  int c = hhmm.indexOf(':');
  if (c < 0) return 0;
  return hhmm.substring(0, c).toInt() * 60 + hhmm.substring(c + 1).toInt();
}

String currentTimestampISO() {
  DateTime now = rtc.now();
  char buf[32];
  snprintf(buf, sizeof(buf), "%04d-%02d-%02dT%02d:%02d:%02d%s", now.year(), now.month(), now.day(), now.hour(), now.minute(), now.second(), TIMEZONE_OFFSET);
  return String(buf);
}

String formatClockForDisplay() {
  DateTime now = rtc.now();
  const char* days[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  int h24 = now.hour();
  int h12 = h24 % 12 == 0 ? 12 : h24 % 12;
  const char* ampm = h24 >= 12 ? "PM" : "AM";
  char buf[24];
  snprintf(buf, sizeof(buf), "%s %02d:%02d %s", days[now.dayOfTheWeek()], h12, now.minute(), ampm);
  return String(buf);
}

int countQueueEntries() {
  if (!LittleFS.exists(QUEUE_FILE)) return 0;
  File f = LittleFS.open(QUEUE_FILE, FILE_READ);
  if (!f) return 0;
  int count = 0;
  while (f.available()) { String l = f.readStringUntil('\n'); l.trim(); if (l.length() > 0) count++; }
  f.close();
  return count;
}

void refreshStatusScreen() {
  bool online = WiFi.status() == WL_CONNECTED;
  bool active = isClassInSession();
  String subjectName = active ? getActiveSubjectName() : "";
  displayStatusScreen(formatClockForDisplay(), online, active, subjectName, countQueueEntries());
}

void attemptAttendanceScan() {
  if (millis() - lastScanTime < SCAN_COOLDOWN_MS) return;
  int p = finger.getImage();
  if (p != FINGERPRINT_OK) return;
  p = finger.image2Tz();
  if (p != FINGERPRINT_OK) { Serial.println("Could not process fingerprint image."); return; }
  p = finger.fingerFastSearch();
  if (p != FINGERPRINT_OK) {
    Serial.println("No match found for this finger.");
    displayScanResult("Unknown", "rejected", "No match found");
    delay(1500);
    refreshStatusScreen();
    lastScanTime = millis();
    return;
  }
  int matchedSlot = finger.fingerID;
  String timestamp = currentTimestampISO();
  Serial.printf("Match: slot #%d at %s\n", matchedSlot, timestamp.c_str());
  String slotLabel = "Slot #" + String(matchedSlot);
  if (sendAttendanceScan(matchedSlot, timestamp)) {
    if (lastResultStatus.length() > 0) displayScanResult(slotLabel, lastResultStatus, lastResultSubject);
    else displayScanResult(slotLabel, "rejected", "See serial log");
  } else {
    Serial.println("Backend unreachable -- queueing scan for later sync.");
    queueScanOffline(matchedSlot, timestamp);
    displayScanResult(slotLabel, "queued", "Will sync later");
  }
  delay(2000);
  refreshStatusScreen();
  lastScanTime = millis();
}

bool sendAttendanceScan(int fingerprintId, String timestamp) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  String url = String(BACKEND_BASE_URL) + "/attendance/scan";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);
  JsonDocument body;
  body["fingerprintId"] = fingerprintId;
  body["scannedAt"] = timestamp;
  String payload;
  serializeJson(body, payload);
  int status = http.POST(payload);
  String response = http.getString();
  http.end();
  if (status <= 0) return false;
  lastResultStatus = "";
  lastResultSubject = "";
  if (status == 201) {
    JsonDocument doc;
    if (!deserializeJson(doc, response)) {
      lastResultStatus = doc["status"].as<String>();
      lastResultSubject = doc["subject"]["name"].as<String>();
    }
    Serial.println("Attendance recorded: " + response);
  } else {
    Serial.printf("Attendance scan rejected (HTTP %d): %s\n", status, response.c_str());
  }
  return true;
}

void queueScanOffline(int fingerprintId, String timestamp) {
  File f = LittleFS.open(QUEUE_FILE, FILE_APPEND);
  if (!f) { Serial.println("Failed to open queue file for writing."); return; }
  JsonDocument doc;
  doc["fingerprintId"] = fingerprintId;
  doc["scannedAt"] = timestamp;
  String line;
  serializeJson(doc, line);
  f.println(line);
  f.close();
  Serial.println("Queued offline: " + line);
}

void flushOfflineQueue() {
  if (!LittleFS.exists(QUEUE_FILE)) return;
  File f = LittleFS.open(QUEUE_FILE, FILE_READ);
  if (!f) return;
  if (f.size() == 0) { f.close(); return; }
  Serial.println("Flushing offline queue...");
  displayMessage("Syncing...", "Sending queued scans", COLOR_AMBER);
  String remaining = "";
  int deliveredCount = 0;
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;
    JsonDocument doc;
    if (deserializeJson(doc, line)) continue;
    int fingerprintId = doc["fingerprintId"];
    String timestamp = doc["scannedAt"].as<String>();
    bool delivered = sendAttendanceScan(fingerprintId, timestamp);
    if (delivered) deliveredCount++;
    else remaining += line + "\n";
    delay(150);
  }
  f.close();
  displayMessage("Sync complete", String(deliveredCount) + " scan(s) sent", COLOR_TEAL);
  delay(1500);
  refreshStatusScreen();
  LittleFS.remove(QUEUE_FILE);
  if (remaining.length() > 0) {
    File out = LittleFS.open(QUEUE_FILE, FILE_WRITE);
    if (out) { out.print(remaining); out.close(); }
  }
}

void checkForEnrollCommand() {
  HTTPClient http;
  String url = String(BACKEND_BASE_URL) + "/device/command";
  http.begin(url);
  http.addHeader("X-Device-Key", DEVICE_KEY);
  int status = http.GET();
  if (status != 200) { http.end(); return; }
  String response = http.getString();
  http.end();
  JsonDocument doc;
  if (deserializeJson(doc, response)) return;
  const char* action = doc["action"];
  if (action && strcmp(action, "enroll") == 0) {
    String requestId = doc["requestId"].as<String>();
    int slot = doc["slot"];
    Serial.printf("Enrollment requested for slot #%d\n", slot);
    bool success = enrollFingerprint(slot);
    reportEnrollResult(requestId, slot, success);
    refreshStatusScreen();
  }
}

bool enrollFingerprint(int slot) {
  displayEnrollStep(1);
  int p = -1;
  unsigned long startTime = millis();
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    if (millis() - startTime > 15000) { displayMessage("Enroll failed", "Timed out", COLOR_CORAL); delay(2000); return false; }
  }
  p = finger.image2Tz(1);
  if (p != FINGERPRINT_OK) { displayMessage("Enroll failed", "Bad image", COLOR_CORAL); delay(2000); return false; }

  displayEnrollStep(2);
  delay(1500);
  p = 0;
  while (p != FINGERPRINT_NOFINGER) p = finger.getImage();

  displayEnrollStep(3);
  p = -1;
  startTime = millis();
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    if (millis() - startTime > 15000) { displayMessage("Enroll failed", "Timed out", COLOR_CORAL); delay(2000); return false; }
  }
  p = finger.image2Tz(2);
  if (p != FINGERPRINT_OK) { displayMessage("Enroll failed", "Bad image", COLOR_CORAL); delay(2000); return false; }

  displayEnrollStep(4);
  p = finger.createModel();
  if (p != FINGERPRINT_OK) { displayMessage("Enroll failed", "Prints didn't match", COLOR_CORAL); delay(2000); return false; }
  p = finger.storeModel(slot);
  if (p != FINGERPRINT_OK) { displayMessage("Enroll failed", "Storage error", COLOR_CORAL); delay(2000); return false; }

  displayMessage("Enrolled", "Slot #" + String(slot), COLOR_TEAL);
  delay(2000);
  return true;
}

void reportEnrollResult(String requestId, int slot, bool success) {
  HTTPClient http;
  String url = String(BACKEND_BASE_URL) + "/device/enroll-result";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);
  JsonDocument body;
  body["requestId"] = requestId;
  body["slot"] = slot;
  body["success"] = success;
  String payload;
  serializeJson(body, payload);
  int status = http.POST(payload);
  http.end();
  Serial.printf("Enroll result reported (HTTP %d)\n", status);
}
